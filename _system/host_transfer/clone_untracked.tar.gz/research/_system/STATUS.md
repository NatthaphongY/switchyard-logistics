# SW-SYS-06  -  Status of the programme (internal)

> **2026-10-23: superseded for current status.** The tree was extracted to a standalone
> repository on this date (D-23). The copy there carries the current status, the decision log
> and the plans; this folder is the backup, and it holds the only copy of commit `8c4d712a` and
> of the uncommitted work until that history is transferred. Do not treat this file as current.

| Field | Value |
|---|---|
| Document ID | SW-SYS-06 |
| Kind | System record (internal; not published) |
| Version | 1.0 |
| Status | Active |
| Date | 2026-10-23 |

## 1. Where the work stands

| Item | State |
|---|---|
| Workstream B (logistics) | Complete through gate B4; the gate separates on six pre-registered criteria |
| Workstream A (EDA) | Suspended, unstaffed, not part of any release |
| Published tree | De-branded: no document prefix, module name, crate name, environment variable, or host path that points back to the publisher |
| Document split | Repository documents and system records are separated by directory and enforced by `tests/test_doc_separation_s.py` |
| Ambient layer | Frozen July 1991-2020 ERA5 climatology, three measured sites plus a synthetic profile for replay |
| Public release | Not prepared |
| Separation | Not done: the tree still lives inside the host tree, and duplication with it has not been measured (SW-SYS-09, tasks A and B) |
| Future projects | Three candidates recorded, none started (SW-SYS-09 section 5) |

## 2. Open items

1. Personal data outside `research/` (two test files, two configuration files) is not scrubbed.
   Those files belong to the host production tree, which this programme must not modify, so the
   decision is the owner's: scrub in place, move them to an ignored path, or accept them.
2. No live forecast ingest. The seam exists (`weather.active_profile`, `SW_WEATHER_PROFILE`);
   only the snapshot is frozen.
3. Rust conformance was re-run after the module and crate rename: 300 exported instances,
   eight threads, 200 repeats, zero mismatches at 26,956 instances per second, and a replay
   of five exported scenarios with zero mismatches. The evidence files still describe the
   pre-rename binary, so the numbers in them are unchanged and still true.
4. The complete repository test suite is not green on this machine for reasons unrelated to
   this programme. The programme gates are listed in `research/README.md` section 7.
5. Separation from the host tree is a recorded task, not a started one: see SW-SYS-09,
   tasks A and B. Until the move happens, this tree is only separated by a directory name,
   which is not separation.
6. Duplication between this tree and the host tree has never been measured. Deleting on the
   strength of a filename would be wrong: a file that looks duplicated may be the second
   implementation that carries the conformance claim.
7. Measured on 2026-10-23: the folder that holds this tree is a copy of the host repository,
   318.1 MB against 6.8 MB for the tree itself. It is one commit ahead and zero behind, so
   apart from commit `8c4d712a` the duplication is total. Deleting the folder before that
   commit and the uncommitted work are preserved destroys the only copy of both. The
   sequence is in SW-SYS-09.

## 3. Next review

Features, security, and code quality are the next pass. Order matters: security before
features, because a feature added on an unreviewed surface is a feature that has to be reviewed
twice.
