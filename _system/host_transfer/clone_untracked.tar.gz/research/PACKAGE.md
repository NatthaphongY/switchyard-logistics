# SW-PKG  -  Package Manifest

| Field | Value |
|---|---|
| Document ID | SW-PKG |
| Kind | Repository document (published) |
| Version | 1.0 |
| Status | Active |
| Date | 2026-10-23 |
| Scope | The exact set of paths that make up the published artefact |
| Enforced by | `tests/test_doc_separation_s.py` |

## 1. Rule

Two kinds of writing live under `research/`: repository documents, which describe the artefact
and how to reproduce it, and system records, which are the working record of the programme
(decisions, plans, status, professional material). Only the first kind is published.

This file is the single answer to "what is published". A path is published when it appears in
section 2 and nowhere else. A path that is not listed is not published, even if it is committed.

## 2. Published paths

```
research/README.md
research/PACKAGE.md
research/docs/02_TRACK_B_COLDCHAIN.md
research/docs/03_EVIDENCE_2026.md
research/docs/05_REPRODUCTION.md
research/docs/06_EVENT_AGNOSTIC_GATE.md
research/docs/07_LICENSING.md
research/docs/08_B4_MEASUREMENT.md
research/docs/09_CATALYST_LAYER.md
research/docs/10_NUMERIC_CORE.md
research/docs/11_PHYSICS_LAYERS.md
research/docs/12_ROBUSTNESS.md
research/config/
research/evidence/
research/src/switchyard/
research/scripts/
research/engine/Cargo.toml
research/engine/Cargo.lock
research/engine/src/main.rs
```

## 3. Deliberately not published

| Path | Content | Why not |
|---|---|---|
| `research/_system/` | Decision log, programme rules, plans, status, professional material, host-system audit | Internal record. A decision log invites an argument about the decision instead of the measurement, and professional material is personal |
| `research/engine/target/` | Cargo build output | Records the host toolchain path; git-ignored |
| `__pycache__/`, `.pytest_cache/` | Interpreter and test caches | Machine state |

## 4. How the boundary is enforced

1. `tests/test_doc_separation_s.py` fails if a published document contains a decision
   identifier, a personal reference, a personal-name class token, or the string `_system`.
2. The same test fails if a path in section 2 does not exist, if a document under `docs/` is
   missing from section 2, or if a `_system` path appears in it.
3. `tests/test_research_scrub_s.py` fails on a personal name, an e-mail address, a phone
   number, a host path, or a third-party product token anywhere in the tree that git would
   publish.
4. `tests/test_research_project_s.py` fails if a document loses its identification block, its
   ASCII property, or its metadata.

## 5. Release checklist

1. Run the gates in `docs/05_REPRODUCTION.md` section 5.
2. Confirm that section 2 above lists every document under `docs/` and nothing under `_system/`.
3. Publish the paths in section 2. Do not publish the branch as a whole: it contains the
   internal records by design.
